"use strict";
exports.id = 164;
exports.ids = [164];
exports.modules = {

/***/ 1164:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const Newsletter = ()=>{
    const [getEmail, setEmail] = useState({
        email: ""
    });
    const subscribeData = {
        email: getEmail.email && getEmail.email
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        try {
            await axios.post(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}subscribe-email`, subscribeData, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }).then((result)=>{
            // console.log(result.data);
            })// .then((result) => setPostComment(result.data))
            .catch(function(error) {
                if (error.response) {
                // Request made and server responded
                // console.log(error.response.data);
                // console.log(error.response.status);
                // console.log(error.response.headers);
                } else if (error.request) {
                // The request was made but no response was received
                // console.log(error.request);
                } else {
                // Something happened in setting up the request that triggered an Error
                // console.log("Error", error.message);
                }
            });
        } catch (error) {
            throw error;
        }
    };
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsx("div", {
            class: "site-section bg-lightx",
            children: /*#__PURE__*/ _jsx("div", {
                class: "container",
                children: /*#__PURE__*/ _jsx("div", {
                    class: "row justify-content-center text-center",
                    children: /*#__PURE__*/ _jsx("div", {
                        class: "col-md-5",
                        children: /*#__PURE__*/ _jsxs("div", {
                            class: "subscribe-1",
                            children: [
                                /*#__PURE__*/ _jsx("h2", {
                                    children: "Subscribe to our newsletter"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    class: "mb-5",
                                    children: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sit nesciunt error illum a explicabo, ipsam nostrum."
                                }),
                                /*#__PURE__*/ _jsxs("form", {
                                    action: "#",
                                    class: "d-flex",
                                    children: [
                                        /*#__PURE__*/ _jsx("input", {
                                            type: "text",
                                            class: "form-control",
                                            placeholder: "Enter your email address",
                                            onChange: (e)=>setEmail({
                                                    ...getEmail,
                                                    email: e.target.value
                                                })
                                        }),
                                        /*#__PURE__*/ _jsx("input", {
                                            type: "submit",
                                            class: "btn btn-primary",
                                            value: "Subscribe"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Newsletter)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;