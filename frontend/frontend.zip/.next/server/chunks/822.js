"use strict";
exports.id = 822;
exports.ids = [822];
exports.modules = {

/***/ 9122:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _MainMeta__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7209);
/* harmony import */ var _SideMeta__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5035);
/* harmony import */ var _InnerMeta__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6769);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__, _MainMeta__WEBPACK_IMPORTED_MODULE_4__, _SideMeta__WEBPACK_IMPORTED_MODULE_5__, _InnerMeta__WEBPACK_IMPORTED_MODULE_6__]);
([axios__WEBPACK_IMPORTED_MODULE_2__, _MainMeta__WEBPACK_IMPORTED_MODULE_4__, _SideMeta__WEBPACK_IMPORTED_MODULE_5__, _InnerMeta__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const Categories = ()=>{
    const [getMainCategories, setMainCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [getSideCategories, setSideCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [getInnerCategories, setInnerCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const getData = async ()=>{
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}seekcategories?per_page=1`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setMainCategories(result.data))//   .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}seekcategories?per_page=4`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setSideCategories(result.data.slice(3)))//   .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}seekcategories?per_page=3`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setInnerCategories(result.data.slice(1)))//   .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "site-section bg-light",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "container",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "row align-items-stretch retro-layout",
                        children: [
                            getSideCategories ? getSideCategories.map((item)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    class: "col-md-5 order-md-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SideMeta__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        propsData: {
                                            catId: item.id,
                                            mediaId: item.acf["category_image"],
                                            count: item.count,
                                            name: item.name,
                                            description: item.description
                                        }
                                    })
                                });
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_7__.Spin, {}),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                class: "col-md-7",
                                children: [
                                    getMainCategories ? getMainCategories.map((item)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MainMeta__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            propsData: {
                                                catId: item.id,
                                                mediaId: item.acf["category_image"],
                                                count: item.count,
                                                name: item.name,
                                                description: item.description
                                            }
                                        });
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_7__.Spin, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        class: "two-col d-block d-md-flex",
                                        children: getInnerCategories ? getInnerCategories.map((item)=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InnerMeta__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                propsData: {
                                                    catId: item.id,
                                                    mediaId: item.acf["category_image"],
                                                    count: item.count,
                                                    name: item.name,
                                                    description: item.description
                                                }
                                            });
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_7__.Spin, {})
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                        href: "/allcategories",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            style: {
                                margin: "5% 0 5% 1%"
                            },
                            class: "btn btn-primary",
                            value: "Browser All"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Categories);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7209:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const MainMeta = ({ propsData  })=>{
    const [getMainMeta, setMainMeta] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const getData = async ()=>{
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}media/${propsData.mediaId && propsData.mediaId}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setMainMeta(result.data))// .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
            href: `postsbycategory/${propsData && propsData.catId}`,
            legacyBehavior: true,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                class: "hentry img-2 v-height mb30 gradient",
                style: {
                    backgroundImage: `url(${getMainMeta ? getMainMeta && getMainMeta.guid && getMainMeta.guid.rendered : "http://seekwordpress.com/wp-content/uploads/2023/01/hero.png"})`
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        class: "post-category text-white bg-success",
                        children: propsData && propsData.count
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "text text-sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: propsData && propsData.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: propsData && propsData.description
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainMeta);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5035:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const SideMeta = ({ propsData  })=>{
    const [getSideMeta, setSideMeta] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const getData = async ()=>{
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}media/${propsData.mediaId && propsData.mediaId}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setSideMeta(result.data))// .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
            href: `postsbycategory/${propsData && propsData.catId}`,
            legacyBehavior: true,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                class: "hentry img-1 h-100 gradient",
                style: {
                    backgroundImage: `url(${getSideMeta ? getSideMeta && getSideMeta.guid && getSideMeta.guid.rendered : "http://seekwordpress.com/wp-content/uploads/2023/01/hero.png"})`
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        class: "post-category text-white bg-danger",
                        children: [
                            " ",
                            propsData && propsData.count
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "text",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: propsData && propsData.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: propsData && propsData.description
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideMeta);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8148:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _featured_FeaturedMedia__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(704);
/* harmony import */ var _featured_FeaturedPostMeta__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7435);
/* harmony import */ var _featured_CenterFeaturedPostMeta__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1434);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__, _featured_FeaturedMedia__WEBPACK_IMPORTED_MODULE_4__, _featured_FeaturedPostMeta__WEBPACK_IMPORTED_MODULE_5__, _featured_CenterFeaturedPostMeta__WEBPACK_IMPORTED_MODULE_6__]);
([axios__WEBPACK_IMPORTED_MODULE_2__, _featured_FeaturedMedia__WEBPACK_IMPORTED_MODULE_4__, _featured_FeaturedPostMeta__WEBPACK_IMPORTED_MODULE_5__, _featured_CenterFeaturedPostMeta__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const FeaturedPosts = ()=>{
    const [FeaturedPosts, setFeaturedPosts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [centerFeaturedPosts, setCenterFeaturedPosts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [rightFeaturedPosts, setRightFeaturedPosts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const config = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    const getData = async ()=>{
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}seekblog?per_page=2`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setFeaturedPosts(result.data))//   .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}seekblog?per_page=3`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setCenterFeaturedPosts(result.data.slice(2)))// .then((result) => console.log(result.data.slice(2)))
        .catch(function(error) {
            if (error.response) {
                // Request made and server responded
                console.log(error.response.data);
                console.log(error.response.status);
                console.log(error.response.headers);
            } else if (error.request) {
                // The request was made but no response was received
                console.log(error.request);
            } else {
                // Something happened in setting up the request that triggered an Error
                console.log("Error", error.message);
            }
        });
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}seekblog?per_page=5`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setRightFeaturedPosts(result.data.slice(3)))// .then((result) => console.log(result.data.slice(2)))
        .catch(function(error) {
            if (error.response) {
                // Request made and server responded
                console.log(error.response.data);
                console.log(error.response.status);
                console.log(error.response.headers);
            } else if (error.request) {
                // The request was made but no response was received
                console.log(error.request);
            } else {
                // Something happened in setting up the request that triggered an Error
                console.log("Error", error.message);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "site-section bg-light",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "container",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        class: "row mb-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "col-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: "Featured Posts"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        class: "row align-items-stretch retro-layout-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                class: "col-md-4",
                                children: FeaturedPosts ? FeaturedPosts.map((item)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_featured_FeaturedPostMeta__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        propsData: {
                                            postId: item.id,
                                            featuredMedia: item.featured_media,
                                            featuredTitle: item["title"]["rendered"],
                                            featuredDate: item.modified
                                        }
                                    });
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_7__.Spin, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                class: "col-md-4",
                                children: centerFeaturedPosts ? centerFeaturedPosts.map((item)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_featured_CenterFeaturedPostMeta__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        propsData: {
                                            postId: item.id,
                                            featuredMedia: item.featured_media,
                                            featuredTitle: item["title"]["rendered"],
                                            featuredDate: item.modified
                                        }
                                    });
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_7__.Spin, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                class: "col-md-4",
                                children: rightFeaturedPosts ? rightFeaturedPosts.map((item)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_featured_FeaturedPostMeta__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        propsData: {
                                            postId: item.id,
                                            featuredMedia: item.featured_media,
                                            featuredTitle: item["title"]["rendered"],
                                            featuredDate: item.modified
                                        }
                                    });
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_7__.Spin, {})
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeaturedPosts);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8694:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _recent_FeaturedMedia__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8078);
/* harmony import */ var _recent_RecentPostMeta__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4662);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__, _recent_FeaturedMedia__WEBPACK_IMPORTED_MODULE_4__, _recent_RecentPostMeta__WEBPACK_IMPORTED_MODULE_5__]);
([axios__WEBPACK_IMPORTED_MODULE_2__, _recent_FeaturedMedia__WEBPACK_IMPORTED_MODULE_4__, _recent_RecentPostMeta__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const Recent = ()=>{
    const [RecentPosts, setRecentPosts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [getPagination, setPagination] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(10);
    var pagination = ()=>{
        setPagination(getPagination + 5);
    };
    const getData = async ()=>{
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}seekblog?per_page=${getPagination}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setRecentPosts(result.data))//   .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "site-section",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "container",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        class: "row mb-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "col-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: "Recent Posts"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        class: "row",
                        children: RecentPosts ? RecentPosts.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                class: "col-lg-4 mb-4",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    class: "entry2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_recent_FeaturedMedia__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            propsData: {
                                                postId: item.id,
                                                featuredMedia: item.featured_media
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_recent_RecentPostMeta__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            propsData: {
                                                postId: item.id,
                                                auhtorId: item.author,
                                                postTitle: item["title"]["rendered"],
                                                postExcerpt: item["excerpt"]["rendered"],
                                                postDate: item.date,
                                                catIds: item.seekcategories
                                            }
                                        })
                                    ]
                                })
                            });
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Spin, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        class: "row text-center pt-5 border-top",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            class: "col-md-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                class: "custom-pagination",
                                children: getPagination > 10 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    onClick: pagination,
                                    class: "btn btn-primary",
                                    value: "Load More"
                                }) : null
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Recent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1434:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const centertFeaturedPostMeta = ({ propsData  })=>{
    const [centerFeaturedPostMeta, setCenterFeaturedPostMeta] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const getData = async ()=>{
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}media/${propsData.featuredMedia && propsData.featuredMedia}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setCenterFeaturedPostMeta(result.data))// .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
        href: `posts/${propsData && propsData.postId}`,
        legacyBehavior: true,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            class: "h-entry img-5 h-100 gradient",
            style: {
                backgroundImage: `url(${centerFeaturedPostMeta ? centerFeaturedPostMeta && centerFeaturedPostMeta.guid && centerFeaturedPostMeta.guid.rendered : "http://seekwordpress.com/wp-content/uploads/2023/01/hero.png"})`
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "text",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        children: propsData && propsData.featuredTitle
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        class: "date",
                        children: propsData && propsData.featuredDate
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (centertFeaturedPostMeta);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 704:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const FeaturedMedia = ({ propsData  })=>{
    const [getFeaturedMedia, setFeaturedMedia] = useState();
    const getData = async ()=>{
        // Get Posts
        await axios.get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}media/${propsData.featuredMedia && propsData.featuredMedia}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setFeaturedMedia(result.data))// .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
    };
    useEffect(()=>{
        getData();
    }, []);
    return /*#__PURE__*/ _jsx(Link, {
        href: `posts/${propsData && propsData.postId}`,
        legacyBehavior: true,
        children: /*#__PURE__*/ _jsx("a", {
            class: "h-entry mb-30 v-height gradient",
            style: {
                backgroundImage: `url(${getFeaturedMedia && getFeaturedMedia.guid && getFeaturedMedia.guid.rendered})`
            },
            children: /*#__PURE__*/ _jsxs("div", {
                class: "text",
                children: [
                    /*#__PURE__*/ _jsx("h2", {
                        children: propsData && propsData.featuredTitle
                    }),
                    /*#__PURE__*/ _jsx("span", {
                        class: "date",
                        children: propsData && propsData.featuredDate
                    })
                ]
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (FeaturedMedia)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7435:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";
const FeaturedPostMeta = ({ propsData  })=>{
    const [getFeaturedPostMeta, setFeaturedPostMeta] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const config = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    const getData = async ()=>{
        // Get Posts
        await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`${"https://api.seekwordpress.com/wp-json/wp/v2/"}media/${propsData.featuredMedia && propsData.featuredMedia}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }).then((result)=>setFeaturedPostMeta(result.data))// .then((result) => console.log(result.data))
        .catch(function(error) {
            if (error.response) {
            // Request made and server responded
            // console.log(error.response.data);
            // console.log(error.response.status);
            // console.log(error.response.headers);
            } else if (error.request) {
            // The request was made but no response was received
            // console.log(error.request);
            } else {
            // Something happened in setting up the request that triggered an Error
            // console.log("Error", error.message);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getData();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
        href: `posts/${propsData && propsData.postId}`,
        legacyBehavior: true,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            class: "h-entry mb-30 v-height gradient",
            style: {
                backgroundImage: `url(${getFeaturedPostMeta ? getFeaturedPostMeta && getFeaturedPostMeta.guid && getFeaturedPostMeta.guid.rendered : "http://seekwordpress.com/wp-content/uploads/2023/01/hero.png"})`
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                class: "text",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        children: propsData && propsData.featuredTitle
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        class: "date",
                        children: propsData && propsData.featuredDate
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeaturedPostMeta);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6781:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_posts_FeaturedPosts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8148);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_posts_FeaturedPosts__WEBPACK_IMPORTED_MODULE_2__]);
_components_posts_FeaturedPosts__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Main = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_posts_FeaturedPosts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Main);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;