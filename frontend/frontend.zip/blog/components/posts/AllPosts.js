import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import axios from "axios";
import { useRouter } from "next/router";
import FeaturedMedia from "./recent/FeaturedMedia";
import RecentPostMeta from "./recent/RecentPostMeta";
import { Spin } from 'antd';
const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEsIm5hbWUiOiJibG9nIiwiaWF0IjoxNjc0Mzk1NTI3LCJleHAiOjE4MzIwNzU1Mjd9.fzB04MWS5fh3IeDe6gaHukRHkahIqwZ52YWUIG7C5oc";

const AllPosts = ({ propsData }) => {
  const [getByCategory, setByCategory] = useState();
  const [getPagination, setPagination] = useState(10);
  var pagination = () => {
    setPagination(getPagination + 5)
  }

  const getData = async () => {
    // Get Post Details
    await axios
      .get(
        `${process.env.NEXT_PUBLIC_BACKEND_API}seekblog?seekcategories=${propsData && propsData.catId
        }`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        })
      .then((result) => setByCategory(result.data))
      // .then((result) => console.log(result.data[0]["title"]["rendered"]))
      // .then((result) => console.log(result.data))
      .catch(function (error) {
        if (error.response) {
          // Request made and server responded
          // console.log(error.response.data);
          // console.log(error.response.status);
          // console.log(error.response.headers);
        } else if (error.request) {
          // The request was made but no response was received
          // console.log(error.request);
        } else {
          // Something happened in setting up the request that triggered an Error
          // console.log("Error", error.message);
        }
      });
  };

  useEffect(() => {
    // console.log(pid);
    getData();
  }, []);
  return (
    <>
      <div className="site-section bg-white">
        <div className="container">
          <div className="row">
            {getByCategory ? (
              getByCategory.map((item) => {
                return (
                  <div className="col-lg-4 mb-4">
                    <div className="entry2">
                      <FeaturedMedia
                        propsData={{
                          postId: item.id,
                          featuredMedia: item.featured_media,
                        }}
                      />
                      <RecentPostMeta
                        propsData={{
                          postId: item.id,
                          auhtorId: item.author,
                          postTitle: item["title"]["rendered"],
                          postExcerpt: item["excerpt"]["rendered"],
                          postDate: item.date,
                          catIds: item.seekcategories,
                        }}
                      />
                    </div>
                  </div>
                );
              })
            ) : (
             <Spin/>
            )}


          </div>
          <div className="row text-center pt-5 border-top">
            <div className="col-md-12">
              <div className="custom-pagination">
                {
                  getPagination > 10 ? <input onClick={pagination} class="btn btn-primary" value="Load More" /> : null
                }
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AllPosts;
