import React from "react";
import FeaturedPosts from "../../components/posts/FeaturedPosts"


const Main = () => {
  return (
    <>
    <FeaturedPosts/>
    </>
  );
};

export default Main;
